INPUT_DIR="../../dataset/original"
OUTPUT_DIR="../../dataset/cleaned2"

if [ -d "$OUTPUT_DIR" ]; then rm -Rf $OUTPUT_DIR; fi

cp -r $INPUT_DIR $OUTPUT_DIR

find $OUTPUT_DIR -size  0 -print -delete


