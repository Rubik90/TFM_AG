python3 rs.py
